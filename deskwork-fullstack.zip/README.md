# Deskwork — Task Management Web App

A full-stack task manager built for learning full-stack structure, API
integration, and real-time data handling.

- **Backend:** Python + Flask, REST API, JWT authentication, MongoDB
- **Real-time:** Flask-SocketIO — task changes push instantly to every tab
  you have open, signed in as the same user
- **Frontend:** plain HTML, CSS and JavaScript (no build step, no framework)
- **Auth:** register/login with hashed passwords, JWT-protected routes, each
  user only ever sees their own tasks

## Project structure

```
deskwork/
├── backend/
│   ├── app/
│   │   ├── __init__.py        # app factory: wires up config, DB, routes
│   │   ├── config.py          # reads settings from .env
│   │   ├── extensions.py      # Mongo client, JWT manager, SocketIO
│   │   ├── sockets.py         # real-time event handlers
│   │   ├── models/            # database access (users, tasks)
│   │   ├── routes/            # REST API endpoints (auth, tasks)
│   │   └── utils/             # password hashing
│   ├── run.py                 # entry point — `python run.py`
│   ├── requirements.txt
│   └── .env.example
└── frontend/
    ├── index.html              # login / register page
    ├── dashboard.html          # the task board
    ├── css/style.css
    └── js/
        ├── api.js              # fetch wrapper, JWT storage
        ├── auth.js             # login/register form logic
        └── dashboard.js        # board rendering, drag-and-drop, sockets
```

## 1. Set up MongoDB

Pick one:

- **Local MongoDB** — install it and make sure `mongod` is running
  (default connection string `mongodb://localhost:27017/deskwork` already
  matches `.env.example`).
- **MongoDB Atlas (free tier, no local install)** — create a cluster at
  [mongodb.com/atlas](https://www.mongodb.com/atlas), create a database
  user, and copy the connection string it gives you.

## 2. Set up the backend

```bash
cd backend
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

pip install -r requirements.txt

cp .env.example .env
# open .env and set MONGO_URI (and change JWT_SECRET_KEY to your own random string)

python run.py
```

The server starts on `http://localhost:5000` and serves **both** the API
and the frontend — there's no separate frontend server to run and no CORS
setup needed.

## 3. Use the app

Open `http://localhost:5000` in your browser:

1. Create an account on the **Create account** tab.
2. You're dropped onto the board — add tasks with the `+ Add a task` field
   in each column, drag cards between columns, click the pencil icon to
   edit a task's description, due date or priority.
3. Open the same URL in a second tab (same login) — create or move a task
   in one tab and watch it update in the other instantly. That's the
   Socket.IO real-time layer at work.

## How the pieces fit together

- **Auth:** `POST /api/auth/register` and `/login` hash the password with
  `werkzeug.security` and return a JWT. The frontend stores that token in
  `localStorage` and sends it as `Authorization: Bearer <token>` on every
  API call (`frontend/js/api.js`).
- **CRUD:** `backend/app/routes/tasks.py` exposes
  `GET/POST /api/tasks` and `GET/PUT/DELETE /api/tasks/<id>`, all protected
  by `@jwt_required()`. Every query is scoped to the logged-in user's id,
  so one user can never see or edit another's tasks.
- **Real-time:** `backend/app/sockets.py` authenticates each socket
  connection with the same JWT and joins a room named after the user's id.
  Whenever a task route creates, updates or deletes a task, it emits an
  event to that room (`socketio.emit(..., room=user_id)`), and every open
  tab for that user updates without a page refresh.
- **Responsive design:** the board is a CSS grid that collapses from three
  columns to one under 820px width (see `frontend/css/style.css`), and the
  login card is centered and full-width on small screens.

## Extending it

- Add task comments or attachments as a new MongoDB collection + routes.
- Add password reset via email (Flask-Mail).
- Swap the plain JS frontend for React once you're comfortable with the
  API — the REST endpoints don't need to change at all.
