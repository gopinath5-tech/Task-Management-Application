from datetime import datetime
from bson import ObjectId
from .. import extensions

VALID_STATUSES = {"todo", "doing", "done"}
VALID_PRIORITIES = {"low", "medium", "high"}


def get_tasks_collection():
    return extensions.db.tasks


def public_task(task_doc):
    return {
        "id": str(task_doc["_id"]),
        "title": task_doc["title"],
        "description": task_doc.get("description", ""),
        "status": task_doc.get("status", "todo"),
        "priority": task_doc.get("priority", "medium"),
        "due_date": task_doc.get("due_date"),
        "created_at": task_doc["created_at"].isoformat() if task_doc.get("created_at") else None,
        "updated_at": task_doc["updated_at"].isoformat() if task_doc.get("updated_at") else None,
    }


def list_tasks_for_user(user_id: str, status=None, priority=None, search=None):
    query = {"user_id": user_id}
    if status and status in VALID_STATUSES:
        query["status"] = status
    if priority and priority in VALID_PRIORITIES:
        query["priority"] = priority
    if search:
        query["title"] = {"$regex": search, "$options": "i"}
    cursor = get_tasks_collection().find(query).sort("created_at", -1)
    return [public_task(t) for t in cursor]


def get_task(user_id: str, task_id: str):
    try:
        return get_tasks_collection().find_one({"_id": ObjectId(task_id), "user_id": user_id})
    except Exception:
        return None


def create_task(user_id: str, title, description="", status="todo", priority="medium", due_date=None):
    now = datetime.utcnow()
    doc = {
        "user_id": user_id,
        "title": title.strip(),
        "description": (description or "").strip(),
        "status": status if status in VALID_STATUSES else "todo",
        "priority": priority if priority in VALID_PRIORITIES else "medium",
        "due_date": due_date,
        "created_at": now,
        "updated_at": now,
    }
    result = get_tasks_collection().insert_one(doc)
    doc["_id"] = result.inserted_id
    return doc


def update_task(user_id: str, task_id: str, updates: dict):
    allowed = {"title", "description", "status", "priority", "due_date"}
    clean = {k: v for k, v in updates.items() if k in allowed}

    if "status" in clean and clean["status"] not in VALID_STATUSES:
        clean.pop("status")
    if "priority" in clean and clean["priority"] not in VALID_PRIORITIES:
        clean.pop("priority")
    if "title" in clean:
        clean["title"] = (clean["title"] or "").strip()
        if not clean["title"]:
            clean.pop("title")

    if not clean:
        return get_task(user_id, task_id)

    clean["updated_at"] = datetime.utcnow()
    try:
        get_tasks_collection().update_one(
            {"_id": ObjectId(task_id), "user_id": user_id},
            {"$set": clean},
        )
    except Exception:
        return None
    return get_task(user_id, task_id)


def delete_task(user_id: str, task_id: str):
    try:
        result = get_tasks_collection().delete_one({"_id": ObjectId(task_id), "user_id": user_id})
        return result.deleted_count > 0
    except Exception:
        return False
