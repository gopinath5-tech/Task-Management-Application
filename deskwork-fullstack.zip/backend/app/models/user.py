from datetime import datetime
from bson import ObjectId
from .. import extensions


def get_users_collection():
    return extensions.db.users


def find_user_by_email(email: str):
    return get_users_collection().find_one({"email": email.lower().strip()})


def find_user_by_id(user_id: str):
    try:
        return get_users_collection().find_one({"_id": ObjectId(user_id)})
    except Exception:
        return None


def create_user(name: str, email: str, password_hash: str):
    doc = {
        "name": name.strip(),
        "email": email.lower().strip(),
        "password_hash": password_hash,
        "created_at": datetime.utcnow(),
    }
    result = get_users_collection().insert_one(doc)
    doc["_id"] = result.inserted_id
    return doc


def public_user(user_doc):
    """Strip the password hash before this ever reaches the client."""
    return {
        "id": str(user_doc["_id"]),
        "name": user_doc["name"],
        "email": user_doc["email"],
    }
