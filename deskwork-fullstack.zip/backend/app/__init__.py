from datetime import timedelta
from flask import Flask

from .config import Config
from . import extensions


def create_app():
    app = Flask(
        __name__,
        static_folder=Config.STATIC_FOLDER,
        static_url_path="",
    )
    app.config["JWT_SECRET_KEY"] = Config.JWT_SECRET_KEY
    app.config["JWT_ACCESS_TOKEN_EXPIRES"] = timedelta(hours=Config.JWT_ACCESS_TOKEN_EXPIRES_HOURS)

    extensions.init_mongo(Config.MONGO_URI)
    extensions.jwt.init_app(app)
    extensions.socketio.init_app(app)

    from .routes.auth import auth_bp
    from .routes.tasks import tasks_bp

    app.register_blueprint(auth_bp, url_prefix="/api/auth")
    app.register_blueprint(tasks_bp, url_prefix="/api/tasks")

    from . import sockets  # noqa: F401  registers the socket.io event handlers above

    # Serve the plain HTML/CSS/JS frontend from the same Flask app so
    # there's no separate server and no CORS to configure.
    @app.route("/")
    def index():
        return app.send_static_file("index.html")

    @app.route("/dashboard.html")
    def dashboard():
        return app.send_static_file("dashboard.html")

    return app
