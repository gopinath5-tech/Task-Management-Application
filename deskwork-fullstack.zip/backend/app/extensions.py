from pymongo import MongoClient
from flask_jwt_extended import JWTManager
from flask_socketio import SocketIO

# These start as None/unconfigured and are wired up in create_app()
# so the app factory pattern stays testable.
mongo_client = None
db = None

jwt = JWTManager()
socketio = SocketIO(cors_allowed_origins="*")


def init_mongo(uri: str):
    global mongo_client, db
    mongo_client = MongoClient(uri)
    db = mongo_client.get_default_database()
    return db
