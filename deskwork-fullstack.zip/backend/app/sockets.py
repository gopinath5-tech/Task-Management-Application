from flask_jwt_extended import decode_token
from flask_socketio import join_room

from .extensions import socketio


@socketio.on("connect")
def handle_connect(auth):
    """
    The frontend connects with `io("/", { auth: { token } })`.
    We verify that token and put the socket in a room named after the
    user's id, so task events only ever reach that user's own tabs/devices.
    """
    token = auth.get("token") if isinstance(auth, dict) else None
    if not token:
        return False  # reject the connection

    try:
        decoded = decode_token(token)
        user_id = decoded["sub"]
    except Exception:
        return False  # invalid or expired token

    join_room(user_id)


@socketio.on("disconnect")
def handle_disconnect():
    pass
