import os
from dotenv import load_dotenv

load_dotenv()


class Config:
    MONGO_URI = os.environ.get("MONGO_URI", "mongodb://localhost:27017/deskwork")
    JWT_SECRET_KEY = os.environ.get("JWT_SECRET_KEY", "dev-secret-change-me")
    JWT_ACCESS_TOKEN_EXPIRES_HOURS = int(os.environ.get("JWT_ACCESS_TOKEN_EXPIRES_HOURS", "24"))
    PORT = int(os.environ.get("PORT", "5000"))
    # Where the plain HTML/CSS/JS frontend lives, relative to backend/app/
    STATIC_FOLDER = os.environ.get("STATIC_FOLDER", "../../frontend")
