from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity

from ..models import task as task_model
from ..extensions import socketio

tasks_bp = Blueprint("tasks", __name__)


@tasks_bp.route("", methods=["GET"])
@jwt_required()
def list_tasks():
    user_id = get_jwt_identity()
    tasks = task_model.list_tasks_for_user(
        user_id,
        status=request.args.get("status"),
        priority=request.args.get("priority"),
        search=request.args.get("search"),
    )
    return jsonify({"tasks": tasks}), 200


@tasks_bp.route("", methods=["POST"])
@jwt_required()
def create_task():
    user_id = get_jwt_identity()
    data = request.get_json(silent=True) or {}
    title = (data.get("title") or "").strip()
    if not title:
        return jsonify({"error": "Title is required."}), 400

    doc = task_model.create_task(
        user_id,
        title=title,
        description=data.get("description", ""),
        status=data.get("status", "todo"),
        priority=data.get("priority", "medium"),
        due_date=data.get("due_date"),
    )
    public = task_model.public_task(doc)
    # Push the new task to every other tab/device this user has open.
    socketio.emit("task_created", public, room=user_id)
    return jsonify({"task": public}), 201


@tasks_bp.route("/<task_id>", methods=["GET"])
@jwt_required()
def get_task(task_id):
    user_id = get_jwt_identity()
    doc = task_model.get_task(user_id, task_id)
    if not doc:
        return jsonify({"error": "Task not found."}), 404
    return jsonify({"task": task_model.public_task(doc)}), 200


@tasks_bp.route("/<task_id>", methods=["PUT"])
@jwt_required()
def update_task(task_id):
    user_id = get_jwt_identity()
    data = request.get_json(silent=True) or {}
    doc = task_model.update_task(user_id, task_id, data)
    if not doc:
        return jsonify({"error": "Task not found."}), 404
    public = task_model.public_task(doc)
    socketio.emit("task_updated", public, room=user_id)
    return jsonify({"task": public}), 200


@tasks_bp.route("/<task_id>", methods=["DELETE"])
@jwt_required()
def delete_task(task_id):
    user_id = get_jwt_identity()
    ok = task_model.delete_task(user_id, task_id)
    if not ok:
        return jsonify({"error": "Task not found."}), 404
    socketio.emit("task_deleted", {"id": task_id}, room=user_id)
    return jsonify({"deleted": task_id}), 200
