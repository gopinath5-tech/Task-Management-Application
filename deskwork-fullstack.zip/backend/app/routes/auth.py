from flask import Blueprint, request, jsonify
from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity

from ..models.user import find_user_by_email, create_user, public_user, find_user_by_id
from ..utils.security import hash_password, verify_password

auth_bp = Blueprint("auth", __name__)


@auth_bp.route("/register", methods=["POST"])
def register():
    data = request.get_json(silent=True) or {}
    name = (data.get("name") or "").strip()
    email = (data.get("email") or "").strip().lower()
    password = data.get("password") or ""

    if not name or not email or not password:
        return jsonify({"error": "Name, email and password are all required."}), 400
    if len(password) < 6:
        return jsonify({"error": "Password must be at least 6 characters."}), 400
    if find_user_by_email(email):
        return jsonify({"error": "An account with that email already exists."}), 409

    user = create_user(name, email, hash_password(password))
    token = create_access_token(identity=str(user["_id"]))
    return jsonify({"token": token, "user": public_user(user)}), 201


@auth_bp.route("/login", methods=["POST"])
def login():
    data = request.get_json(silent=True) or {}
    email = (data.get("email") or "").strip().lower()
    password = data.get("password") or ""

    user = find_user_by_email(email)
    if not user or not verify_password(password, user["password_hash"]):
        return jsonify({"error": "Incorrect email or password."}), 401

    token = create_access_token(identity=str(user["_id"]))
    return jsonify({"token": token, "user": public_user(user)}), 200


@auth_bp.route("/me", methods=["GET"])
@jwt_required()
def me():
    user = find_user_by_id(get_jwt_identity())
    if not user:
        return jsonify({"error": "User not found."}), 404
    return jsonify({"user": public_user(user)}), 200
