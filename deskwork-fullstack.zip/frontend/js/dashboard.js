let tasks = [];
let socket = null;
let draggingId = null;
let editingId = null;
const currentFilter = { priority: "all", search: "" };

const COLUMNS = [
  { id: "todo", label: "To do" },
  { id: "doing", label: "In progress" },
  { id: "done", label: "Done" },
];

document.addEventListener("DOMContentLoaded", async () => {
  if (!getToken()) {
    location.href = "index.html";
    return;
  }

  document.getElementById("logoutBtn").addEventListener("click", () => {
    clearToken();
    if (socket) socket.disconnect();
    location.href = "index.html";
  });

  try {
    const me = await apiRequest("/api/auth/me");
    document.getElementById("userName").textContent = me.user.name;
  } catch (err) {
    return; // apiRequest already redirects to login on 401
  }

  bindToolbar();
  bindEditModal();
  connectSocket();

  try {
    const data = await apiRequest("/api/tasks");
    tasks = data.tasks;
    render();
  } catch (err) {
    alert(err.message);
  }
});

function connectSocket() {
  socket = io("/", { auth: { token: getToken() } });

  socket.on("task_created", (task) => {
    if (!tasks.find((t) => t.id === task.id)) tasks.push(task);
    render();
  });
  socket.on("task_updated", (task) => {
    tasks = tasks.map((t) => (t.id === task.id ? task : t));
    render();
  });
  socket.on("task_deleted", ({ id }) => {
    tasks = tasks.filter((t) => t.id !== id);
    render();
  });
}

function bindToolbar() {
  document.getElementById("searchInput").addEventListener("input", (e) => {
    currentFilter.search = e.target.value.trim().toLowerCase();
    render();
  });
  document.getElementById("priorityFilter").addEventListener("change", (e) => {
    currentFilter.priority = e.target.value;
    render();
  });
}

function matchesFilter(task) {
  if (currentFilter.priority !== "all" && task.priority !== currentFilter.priority) return false;
  if (currentFilter.search && !task.title.toLowerCase().includes(currentFilter.search)) return false;
  return true;
}

function render() {
  const board = document.getElementById("board");
  board.innerHTML = "";
  const counts = { todo: 0, doing: 0, done: 0 };
  tasks.forEach((t) => { if (counts[t.status] !== undefined) counts[t.status]++; });

  COLUMNS.forEach((col) => {
    const colEl = document.createElement("div");
    colEl.className = "column";
    colEl.innerHTML = `
      <div class="column-head">
        <h2>${col.label}</h2>
        <span class="count">${counts[col.id]}</span>
      </div>
      <div class="drop-zone" data-status="${col.id}"></div>
      <div class="add-row">
        <input class="add-input" type="text" placeholder="+ Add a task" data-status="${col.id}">
      </div>
    `;
    board.appendChild(colEl);

    const zone = colEl.querySelector(".drop-zone");
    const colTasks = tasks.filter((t) => t.status === col.id && matchesFilter(t));

    if (colTasks.length === 0) {
      const hint = document.createElement("div");
      hint.className = "empty-hint";
      hint.textContent = "Nothing here yet.";
      zone.appendChild(hint);
    }
    colTasks.forEach((task) => zone.appendChild(buildCard(task)));

    zone.addEventListener("dragover", (e) => { e.preventDefault(); zone.classList.add("drag-over"); });
    zone.addEventListener("dragleave", () => zone.classList.remove("drag-over"));
    zone.addEventListener("drop", async (e) => {
      e.preventDefault();
      zone.classList.remove("drag-over");
      if (draggingId) await updateTask(draggingId, { status: col.id });
    });

    const addInput = colEl.querySelector(".add-input");
    addInput.addEventListener("keydown", async (e) => {
      if (e.key === "Enter" && addInput.value.trim()) {
        await createTask(addInput.value.trim(), col.id);
        addInput.value = "";
      }
    });
  });

  document.getElementById("tally").innerHTML = `
    <div><strong>${counts.todo}</strong>to do</div>
    <div><strong>${counts.doing}</strong>in progress</div>
    <div><strong>${counts.done}</strong>done</div>
  `;
}

function buildCard(task) {
  const card = document.createElement("div");
  card.className = "card";
  card.draggable = true;
  card.dataset.id = task.id;
  card.style.setProperty("--card-accent", accentFor(task.priority));

  card.innerHTML = `
    <div class="card-top">
      <p class="card-title"></p>
      <div class="card-actions">
        <button class="icon-btn edit-btn" title="Edit" aria-label="Edit task">✎</button>
        <button class="icon-btn del-btn" title="Delete" aria-label="Delete task">✕</button>
      </div>
    </div>
    <div class="card-meta">
      <span class="pill ${task.priority}">${cap(task.priority)}</span>
      ${task.due_date ? `<span class="due${isOverdue(task) ? ' overdue' : ''}">${dueLabel(task)}</span>` : ""}
    </div>
  `;
  card.querySelector(".card-title").textContent = task.title;

  card.addEventListener("dragstart", () => { draggingId = task.id; card.classList.add("dragging"); });
  card.addEventListener("dragend", () => { draggingId = null; card.classList.remove("dragging"); });

  card.querySelector(".edit-btn").addEventListener("click", (e) => { e.stopPropagation(); openEdit(task); });
  card.querySelector(".del-btn").addEventListener("click", async (e) => {
    e.stopPropagation();
    await deleteTask(task.id);
  });

  return card;
}

function accentFor(priority) {
  return priority === "high" ? "var(--red)" : priority === "low" ? "var(--green)" : "var(--amber)";
}
function cap(s) { return s.charAt(0).toUpperCase() + s.slice(1); }
function isOverdue(task) {
  if (!task.due_date || task.status === "done") return false;
  const today = new Date(); today.setHours(0, 0, 0, 0);
  return new Date(task.due_date) < today;
}
function dueLabel(task) {
  const label = new Date(task.due_date).toLocaleDateString(undefined, { month: "short", day: "numeric" });
  return (isOverdue(task) ? "Overdue · " : "Due ") + label;
}

async function createTask(title, status) {
  try {
    const data = await apiRequest("/api/tasks", {
      method: "POST",
      body: JSON.stringify({ title, status, priority: "medium" }),
    });
    if (!tasks.find((t) => t.id === data.task.id)) tasks.push(data.task);
    render();
  } catch (err) {
    alert(err.message);
  }
}

async function updateTask(id, updates) {
  try {
    const data = await apiRequest(`/api/tasks/${id}`, {
      method: "PUT",
      body: JSON.stringify(updates),
    });
    tasks = tasks.map((t) => (t.id === id ? data.task : t));
    render();
  } catch (err) {
    alert(err.message);
  }
}

async function deleteTask(id) {
  try {
    await apiRequest(`/api/tasks/${id}`, { method: "DELETE" });
    tasks = tasks.filter((t) => t.id !== id);
    render();
  } catch (err) {
    alert(err.message);
  }
}

function openEdit(task) {
  editingId = task.id;
  document.getElementById("editTitle").value = task.title;
  document.getElementById("editDescription").value = task.description || "";
  document.getElementById("editDue").value = task.due_date || "";
  document.getElementById("editPriority").value = task.priority;
  document.getElementById("overlay").classList.add("open");
  document.getElementById("editTitle").focus();
}

function closeEdit() {
  document.getElementById("overlay").classList.remove("open");
  editingId = null;
}

function bindEditModal() {
  const overlay = document.getElementById("overlay");
  document.getElementById("cancelEdit").addEventListener("click", closeEdit);
  overlay.addEventListener("click", (e) => { if (e.target === overlay) closeEdit(); });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape" && overlay.classList.contains("open")) closeEdit(); });

  document.getElementById("saveEdit").addEventListener("click", async () => {
    if (!editingId) return;
    await updateTask(editingId, {
      title: document.getElementById("editTitle").value.trim(),
      description: document.getElementById("editDescription").value.trim(),
      due_date: document.getElementById("editDue").value || null,
      priority: document.getElementById("editPriority").value,
    });
    closeEdit();
  });
}
